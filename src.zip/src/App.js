import Home from './Home'
function App() {
  return (
    <div><Home /></div>
  );
}

export default App;

/// https://codesandbox.io/s/w2v7zzn63w?file=/src/Home.js:1216-1226
